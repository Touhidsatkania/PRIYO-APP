PRIYO STORE V65 FIXED
Application ID: com.priyostore.app
Version: 1.0.65 (65)
Launcher icon: PRIYO STORE PS shopping-cart icon with adaptive icon resources.
Builds debug APK and unsigned release APK.
