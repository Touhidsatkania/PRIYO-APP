PRIYO STORE V71 — STARTUP + ICON FIX

1. Startup changed to a direct local Android asset WebView load: file:///android_asset/index.html.
2. Removed dependency on WebViewAssetLoader from MainActivity startup path.
3. Launcher uses the supplied PS icon PNG resources.
4. Version bumped to 1.0.71 / versionCode 71 so an older APK cannot be mistaken for this build.
5. GitHub Actions version checks/artifact name updated to V71.
6. IMPORTANT: uninstall the older PRIYO STORE APK before testing V71, then install the newly built V71 APK. Android launcher may cache old icons.
