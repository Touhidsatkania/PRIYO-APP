PRIYO STORE V69 — AUTH + ADMIN EMAIL

Added:
- Startup login gate.
- Email login + Create Account.
- Mobile login + Create Account.
- Persistent local account/session structure for prototype.
- Admin role is automatically assigned when the login email matches the configured Admin email.
- Default Admin email: admin@priyostore.com
- Admin email can be changed from Admin Control Center > Dashboard after an admin session.
- Successful Admin login automatically opens Admin Control Center.
- Normal users do not see the Admin Control Center menu item.
- Existing V68 Profile and Facebook-style PRIYO Feed retained.

Important: V69 keeps the current prototype/local account layer. Production-grade password hashing, OTP/SMS and server-side authorization should be backed by the project's secure backend before public release.

V70 — LIVE-ONLY MODERATOR SYSTEM
- Main Admin can grant Moderator power by PRIYO ID from Admin Control Center > Live Moderators.
- Main Admin can revoke Moderator power by PRIYO ID.
- Moderator permission is restricted to Live Streaming only; it does not grant Admin Panel, Store, Feed, Profile or general app control.
- Live Moderator console provides per-stream controls: Close Live, Block User, Mute User and Kick Out.
- Moderator console is available only to an account whose PRIYO ID has been granted moderator power.
- Moderator assignments and prototype moderation state are stored locally for this source/prototype.
- Production release must enforce these permissions server-side so client-side/local storage cannot bypass moderation or admin authorization.
