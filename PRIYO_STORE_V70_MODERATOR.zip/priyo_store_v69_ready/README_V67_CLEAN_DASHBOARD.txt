PRIYO STORE V67 — CLEAN APPROVED DASHBOARD

Approved icon and dashboard reference supplied by user are included in assets.
The Home UI is rebuilt to follow the approved mobile/desktop dashboard: promotional banners, welcome banner, promo cards, Breaking News, Live Now (4 compact cards), LIVE/GO LIVE/Priyo Feed actions, Online Shopping highlighted tile, Gallery, External Movie, Live TV, Social Media, Earn & Reward, Share, More Apps, and 5-item bottom navigation.

Admin Control Center:
- Feature add/edit/enable/disable/order
- Banner add/edit/enable/disable/order
- Breaking News add/edit/enable/disable/order
- Live card add/edit/enable/disable/order
- Configuration is stored separately from UI code so content changes do not require rebuilding the APK.

Important implementation note: V67 currently persists Admin configuration in WebView local storage. A secure cross-device production Admin backend still requires a real backend/authentication service and server credentials; no fake remote security is claimed.
