# PRIYO STORE V66 — GitHub-ready source

This archive is the source-of-truth Android project for the PRIYO STORE V66 corrective build.

- Application ID: `com.priyostore.app`
- Version: `1.0.66` (versionCode 66)
- Launcher icon: PS shopping-cart adaptive icon
- Build workflow verifies the source before compiling.
- The workflow outputs `PRIYO-STORE-V66-APKs`.

**Important:** upload/extract the project contents at the repository root so `.github/workflows/android-build.yml`, `app/`, `build.gradle`, and `settings.gradle` are at the root. Do not upload only this ZIP as the build source.
