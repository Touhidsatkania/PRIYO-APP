PRIYO STORE V69 — PROFILE + FACEBOOK-STYLE PRIYO FEED

Based on V69 clean approved dashboard.

1. Left hamburger (☰) now opens the main navigation drawer from the left.
2. Profile is available directly in that drawer and can be created/edited there.
3. Profile is also exposed from the three-dot menu and bottom Profile navigation.
4. Profile includes PRIYO ID, name, email, bio, location, avatar, friends, followers, following, orders, favorites, live activity, notifications, security, block list, history, rewards, support, terms and logout.
5. PRIYO Feed is rebuilt as a Facebook-style social feed prototype: composer, photo/video selection, feeling, posts, likes, comments and share.
6. Feed and Profile data are stored locally for the prototype. Secure multi-device production sync still requires backend/database authorization.
7. Existing Admin configuration remains intact; content configuration can continue without an APK UI update where supported by the existing Admin system.
