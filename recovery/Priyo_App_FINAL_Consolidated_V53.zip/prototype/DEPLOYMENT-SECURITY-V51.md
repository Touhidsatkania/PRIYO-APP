# PRIYO APP — Deployment Security Gate V-51

This prototype batch hardens the client shell only. Production deployment must still enforce these controls on the server/API layer:

- Authentication and session validation on every protected request.
- Role/permission checks server-side; never trust `window.PRIYO_ROLE` or client storage for admin access.
- Database Row Level Security (RLS) for user-owned data.
- Server-side validation, rate limits and idempotency for likes, saves, comments, views, chat, LIVE actions and notifications.
- Payment verification only through the payment provider/server webhook; never trust client payment status.
- Private storage buckets and signed URLs where media is private.
- Push notification credentials and service secrets kept server-side.
- CORS restricted to deployed application origins.
- HTTPS only plus HSTS, Content-Security-Policy, X-Content-Type-Options, Referrer-Policy and frame-ancestors protections.
- Centralized audit logs for admin actions, moderation and sensitive account changes.

The local prototype must not be treated as a production authorization boundary.
