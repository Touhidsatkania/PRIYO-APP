# PRIYO APP — Production Integration V-52

This batch adds a real Supabase schema/RLS migration and Cloudflare Pages deployment configuration.

## Required before public launch
- Apply `supabase/migrations/20260825_priyo_core.sql` to the intended Supabase production project.
- Verify every RLS policy with authenticated and unauthenticated test users.
- Configure storage buckets and signed/public access according to each media type.
- Connect server-side payment webhook verification; never update payment status from the browser.
- Connect a real LIVE ingest/playback provider and authenticated realtime channels.
- Configure push notification credentials only as server secrets.
- Configure Cloudflare Pages environment variables from `deploy/.env.example`.
- Add the real PRIYO APP icon assets to the manifest before release.
- Configure the production HTTPS domain and security headers/CSP.
- Perform real-device smoke tests and rollback verification.
