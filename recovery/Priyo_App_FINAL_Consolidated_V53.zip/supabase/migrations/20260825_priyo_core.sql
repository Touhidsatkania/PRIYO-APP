create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  priyo_id text unique not null,
  display_name text not null default 'PRIYO User',
  avatar_url text,
  is_private boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  description text,
  media_url text,
  status text not null default 'published' check (status in ('draft','published','blocked','deleted')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.video_engagements (
  id uuid primary key default gen_random_uuid(),
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('like','save','view','share')),
  created_at timestamptz not null default now(),
  unique(video_id,user_id,kind)
);

create table if not exists public.video_comments (
  id uuid primary key default gen_random_uuid(),
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (length(body) between 1 and 2000),
  status text not null default 'visible' check (status in ('visible','hidden','deleted')),
  created_at timestamptz not null default now()
);

create table if not exists public.live_sessions (
  id uuid primary key default gen_random_uuid(),
  host_user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  status text not null default 'scheduled' check (status in ('scheduled','live','ended')),
  viewer_count integer not null default 0 check (viewer_count >= 0),
  started_at timestamptz,
  ended_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.live_chat_messages (
  id uuid primary key default gen_random_uuid(),
  live_id uuid not null references public.live_sessions(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  message text not null check (length(message) between 1 and 1000),
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  type text not null,
  title text not null,
  body text,
  data jsonb not null default '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  target_type text not null check (target_type in ('video','comment','profile','live','message')),
  target_id uuid not null,
  reason text not null check (length(reason) between 1 and 500),
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.videos enable row level security;
alter table public.video_engagements enable row level security;
alter table public.video_comments enable row level security;
alter table public.live_sessions enable row level security;
alter table public.live_chat_messages enable row level security;
alter table public.notifications enable row level security;
alter table public.reports enable row level security;

-- Profiles: users may manage their own row; public fields are readable.
drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select using (not is_private or id = auth.uid());
drop policy if exists profiles_insert on public.profiles;
create policy profiles_insert on public.profiles for insert with check (id = auth.uid());
drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());

-- Published videos are readable; owners manage their own.
drop policy if exists videos_select on public.videos;
create policy videos_select on public.videos for select using (status = 'published' or owner_id = auth.uid());
drop policy if exists videos_insert on public.videos;
create policy videos_insert on public.videos for insert with check (owner_id = auth.uid());
drop policy if exists videos_update on public.videos;
create policy videos_update on public.videos for update using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- Engagement: users can only write their own events. Server functions should handle counters/rate limits.
drop policy if exists engagement_select on public.video_engagements;
create policy engagement_select on public.video_engagements for select using (user_id = auth.uid());
drop policy if exists engagement_insert on public.video_engagements;
create policy engagement_insert on public.video_engagements for insert with check (user_id = auth.uid());
drop policy if exists engagement_delete on public.video_engagements;
create policy engagement_delete on public.video_engagements for delete using (user_id = auth.uid());

-- Comments: visible comments can be read; users manage their own.
drop policy if exists comments_select on public.video_comments;
create policy comments_select on public.video_comments for select using (status = 'visible' or user_id = auth.uid());
drop policy if exists comments_insert on public.video_comments;
create policy comments_insert on public.video_comments for insert with check (user_id = auth.uid());
drop policy if exists comments_update on public.video_comments;
create policy comments_update on public.video_comments for update using (user_id = auth.uid()) with check (user_id = auth.uid());

-- LIVE sessions are readable; only host can modify.
drop policy if exists live_select on public.live_sessions;
create policy live_select on public.live_sessions for select using (status <> 'scheduled' or host_user_id = auth.uid());
drop policy if exists live_insert on public.live_sessions;
create policy live_insert on public.live_sessions for insert with check (host_user_id = auth.uid());
drop policy if exists live_update on public.live_sessions;
create policy live_update on public.live_sessions for update using (host_user_id = auth.uid()) with check (host_user_id = auth.uid());

-- Chat: authenticated users can read/send only while the session is live.
drop policy if exists live_chat_select on public.live_chat_messages;
create policy live_chat_select on public.live_chat_messages for select using (exists (select 1 from public.live_sessions s where s.id = live_id and s.status = 'live'));
drop policy if exists live_chat_insert on public.live_chat_messages;
create policy live_chat_insert on public.live_chat_messages for insert with check (user_id = auth.uid() and exists (select 1 from public.live_sessions s where s.id = live_id and s.status = 'live'));

-- Notifications are private to recipient.
drop policy if exists notifications_select on public.notifications;
create policy notifications_select on public.notifications for select using (user_id = auth.uid());
drop policy if exists notifications_update on public.notifications;
create policy notifications_update on public.notifications for update using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Reports are private to reporter; moderation staff should use a privileged server role/function.
drop policy if exists reports_select on public.reports;
create policy reports_select on public.reports for select using (reporter_id = auth.uid());
drop policy if exists reports_insert on public.reports;
create policy reports_insert on public.reports for insert with check (reporter_id = auth.uid());

create index if not exists videos_owner_idx on public.videos(owner_id, created_at desc);
create index if not exists video_comments_video_idx on public.video_comments(video_id, created_at desc);
create index if not exists live_sessions_status_idx on public.live_sessions(status, viewer_count desc);
create index if not exists notifications_user_idx on public.notifications(user_id, created_at desc);
create index if not exists reports_status_idx on public.reports(status, created_at asc);
