# PRIYO STORE V72

Clean Android build source for the PRIYO STORE project.

- Application ID: `com.priyostore.app`
- Namespace: `com.priyostore.app`
- Version code: `72`
- Version name: `1.0.72`
- App label: `PRIYO STORE`
- Launcher icon: approved PS icon
- Main screen: `app/src/main/assets/index.html`
- Main activity: `com.priyostore.app.MainActivity`

The GitHub Actions workflow performs a clean build and verifies the package, version, label, launcher icon and startup files before compiling.
