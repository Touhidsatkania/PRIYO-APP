# PRIYO STORE V72

Clean Android build source for the PRIYO STORE project.

- Application ID: `com.priyostore.app`
- Namespace: `com.priyostore.app`
- Version code: `72`
- Version name: `1.0.72`
- App label: `PRIYO STORE`
- Launcher icon: approved PS icon
- Main screen: `app/src/main/assets/index.html`
- Main activity: `com.priyostore.app.MainActivity`

The GitHub Actions workflow performs a clean build and verifies the package, version, label, launcher icon and startup files before compiling.


## V74 CLEAN FINAL UPLOAD
- Final launcher/app icon: `app/src/main/assets/PRIYO_STORE_APPROVED_ICON.png`
- Final dashboard reference: `app/src/main/assets/PRIYO_STORE_APPROVED_DASHBOARD_REFERENCE.png`
- Duplicate prior icon/reference assets removed.
- Android version: 1.0.74 / versionCode 74.
- Admin Appearance/Branding controls remain enabled.
